"use client";

import React from "react";
import { Ic, ic } from "./icons";
import type { Doc } from "./types";

interface DocumentPanelProps {
  documents: Doc[];
  activeDocIdx: number;
  onSelect: (idx: number) => void;
  onUpload: () => void;
  onAddDoc: () => void;
}

export function DocumentPanel({ documents, activeDocIdx, onSelect, onUpload, onAddDoc }: DocumentPanelProps) {
  return (
    <div className="w-[20%] min-w-[180px] border-r border-stone-200 bg-white flex flex-col overflow-hidden">
      <div className="p-3 flex items-center justify-between">
        <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider">Documentos</span>
        <div className="flex gap-1">
          <button onClick={onUpload} className="p-1 rounded bg-stone-50 hover:bg-trama-50 text-trama-500" title="Upload">
            <Ic d={ic.upload} className="w-3.5 h-3.5" />
          </button>
          <button onClick={onAddDoc} className="p-1 rounded bg-stone-50 hover:bg-trama-50 text-trama-500" title="Colar texto">
            <Ic d={ic.plus} className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {documents.length === 0 && (
          <div className="p-4 text-center">
            <p className="text-xs text-stone-400 mb-2">Nenhum documento.</p>
            <button onClick={onUpload} className="text-xs text-trama-500 font-medium">
              Upload
            </button>
          </div>
        )}

        {documents.map((doc, i) => (
          <button
            key={doc.id}
            onClick={() => onSelect(i)}
            className={`w-full text-left px-3 py-2.5 transition border-l-[3px] ${
              activeDocIdx === i ? "bg-orange-50 border-argila" : "border-transparent hover:bg-stone-50"
            }`}
          >
            <div className="flex items-center gap-1.5 mb-1">
              <Ic
                d={doc.type === "AUDIO" ? ic.music : doc.type === "VIDEO" ? ic.film : ic.doc}
                className={`w-3 h-3 shrink-0 ${activeDocIdx === i ? "text-argila" : "text-stone-300"}`}
              />
              <span className={`text-xs truncate ${activeDocIdx === i ? "font-medium text-stone-800" : "text-stone-600"}`}>
                {doc.title}
              </span>
            </div>
            <div className="flex gap-3 pl-[18px]">
              <span className="text-[11px] text-stone-400">
                {doc.type === "AUDIO" || doc.type === "VIDEO" ? doc.type.toLowerCase() : `${doc.wordCount} pal.`}
              </span>
              <span className="text-[11px] text-stone-400">{doc._count.codings} cód.</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
